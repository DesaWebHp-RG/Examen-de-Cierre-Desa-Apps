package xyz.vmartinez.holamundocamara02

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity:AppCompatActivity(){
    private var usuario=-1L
    private var fotoActual:File?=null
    private lateinit var vista:ImageView
    private var coordenadas:Location?=null
    private val permisos=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { obtenerUbicacion() }
    private val camara=registerForActivityResult(ActivityResultContracts.TakePicture()) { correcta ->
        if(correcta) {
            fotoActual?.let { vista.setImageURI(null);vista.setImageURI(Uri.fromFile(it)) }
            obtenerUbicacion()
            solicitarComentario()
        } else { fotoActual?.delete();fotoActual=null;Pantallas.aviso(this,"Se canceló la fotografía") }
    }
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
        usuario=intent.getLongExtra("usuario",-1L)
        if(usuario<0){finish();return}
        val l=Pantallas.columna(this)
        l.addView(Pantallas.encabezado(this,"Fotografías con GPS","Captura, ubicación y comentarios"))
        vista=ImageView(this).apply { minimumHeight=420;adjustViewBounds=true;scaleType=ImageView.ScaleType.FIT_CENTER }
        l.addView(vista)
        l.addView(Pantallas.boton(this,"Tomar foto") { tomarFoto() })
        l.addView(Pantallas.boton(this,"Ver fotos") { startActivity(Intent(this,ListaDeFotosActivity::class.java).putExtra("usuario",usuario)) })
        l.addView(Pantallas.boton(this,"Cerrar sesión") { finish() })
        setContentView(Pantallas.contenido(this,l))
        if(!permisoUbicacion()) permisos.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION))
    }
    private fun permisoUbicacion():Boolean = ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED
    @Suppress("MissingPermission")
    private fun obtenerUbicacion(){
        if(!permisoUbicacion())return
        try {
            val lm=getSystemService(LOCATION_SERVICE) as LocationManager
            coordenadas=listOf(LocationManager.GPS_PROVIDER,LocationManager.NETWORK_PROVIDER).filter {lm.isProviderEnabled(it)}.mapNotNull {lm.getLastKnownLocation(it)}.maxByOrNull{it.time}
            // La última posición conocida puede no existir; se permite guardar la foto sin coordenadas.
        }catch (_:Exception){coordenadas=null}
    }
    private fun tomarFoto(){
        coordenadas=null;obtenerUbicacion()
        val folder=getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        if(folder==null){Pantallas.aviso(this,"No se pudo acceder a la carpeta de fotos");return}
        try {
            val nombre=SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.getDefault()).format(Date())
            fotoActual=File.createTempFile("FOTO_${nombre}_",".jpg",folder)
            val uri=FileProvider.getUriForFile(this,"${applicationContext.packageName}.fileprovider",fotoActual!!)
            camara.launch(uri)
        }catch(e:Exception){Pantallas.aviso(this,"Error al abrir cámara: ${e.message}")}
    }
    private fun solicitarComentario(){
        val campo=EditText(this).apply{hint="Escribe un comentario de la foto";setPadding(28,24,28,24)}
        AlertDialog.Builder(this).setTitle("Guardar fotografía").setMessage("Agrega un comentario para almacenar la foto y su ubicación GPS en SQLite.").setView(campo)
            .setPositiveButton("Guardar") {_,_->
                obtenerUbicacion()
                val f=fotoActual ?:return@setPositiveButton
                val fecha=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.getDefault()).format(Date())
                val ok=DatosDB(this).guardarFoto(usuario,f.absolutePath,coordenadas?.latitude,coordenadas?.longitude,campo.text.toString().trim(),fecha)
                Pantallas.aviso(this,if(ok) "Foto guardada${if(coordenadas==null) " (GPS no disponible)" else " con GPS"}" else "No se pudo registrar la foto")
                if(!ok)f.delete()
                fotoActual=null
            }.setNegativeButton("Descartar") {_,_->fotoActual?.delete();fotoActual=null;vista.setImageDrawable(null)}.setCancelable(false).show()
    }
}
