package xyz.vmartinez.holamundocamara02

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.*

/** Paleta inspirada en UNAM: azul #001B44 y dorado #F4B400. */
object Pantallas {
    private val azul=Color.rgb(0,27,68)
    private val dorado=Color.rgb(244,180,0)
    private val fondo=Color.rgb(245,247,251)
    private fun dp(ctx: Context,n:Int)=(n*ctx.resources.displayMetrics.density+0.5f).toInt()
    private fun forma(color:Int, radio:Float=14f, borde:Int?=null):GradientDrawable = GradientDrawable().apply {
        setColor(color);cornerRadius=radio
        if(borde!=null)setStroke(2,borde)
    }
    fun columna(ctx:Context):LinearLayout=LinearLayout(ctx).apply {
        orientation=LinearLayout.VERTICAL
        setPadding(dp(ctx,22),dp(ctx,24),dp(ctx,22),dp(ctx,26))
        setBackgroundColor(fondo)
    }
    fun texto(ctx:Context,t:String,size:Float=18f):TextView=TextView(ctx).apply {
        text=t;textSize=size;setTextColor(azul)
        setPadding(dp(ctx,4),dp(ctx,12),dp(ctx,4),dp(ctx,12))
        if(size>=23f){setTypeface(null,Typeface.BOLD);setBackgroundColor(Color.TRANSPARENT)}
    }
    fun campo(ctx:Context,hint:String,type:Int=1):EditText=EditText(ctx).apply {
        this.hint=hint;inputType=type;setSingleLine(true);textSize=16f
        setTextColor(azul);setHintTextColor(Color.rgb(106,119,138))
        backgroundTintList=ColorStateList.valueOf(azul)
        setPadding(dp(ctx,12),dp(ctx,12),dp(ctx,12),dp(ctx,12))
        layoutParams=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(ctx,12)}
    }
    fun boton(ctx:Context,t:String,fn:()->Unit):Button=Button(ctx).apply {
        text=t;isAllCaps=false;textSize=16f;setTypeface(null,Typeface.BOLD)
        val secundario=t.contains("Crear cuenta",true)||t.contains("Ver fotos",true)||t.contains("Cerrar sesión",true)
        setTextColor(if(secundario) azul else Color.WHITE)
        backgroundTintList=ColorStateList.valueOf(if(secundario)dorado else azul)
        elevation=dp(ctx,2).toFloat();minHeight=dp(ctx,52)
        layoutParams=LinearLayout.LayoutParams(-1,dp(ctx,54)).apply{topMargin=dp(ctx,8);bottomMargin=dp(ctx,8)}
        setOnClickListener{fn()}
    }
    fun contenido(ctx:Context,contenido:LinearLayout):ScrollView=ScrollView(ctx).apply {
        isFillViewport=true;setBackgroundColor(fondo);addView(contenido)
    }
    fun aviso(ctx:Context,s:String)=Toast.makeText(ctx,s,Toast.LENGTH_LONG).show()
    fun encabezado(ctx:Context,t:String,sub:String):LinearLayout=LinearLayout(ctx).apply {
        orientation=LinearLayout.VERTICAL
        setPadding(dp(ctx,20),dp(ctx,21),dp(ctx,20),dp(ctx,18))
        background=forma(azul,dp(ctx,18).toFloat())
        layoutParams=LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(ctx,24)}
        addView(TextView(ctx).apply{text=t;textSize=23f;setTextColor(Color.WHITE);setTypeface(null,Typeface.BOLD)})
        addView(TextView(ctx).apply{text=sub;textSize=14f;setTextColor(dorado);setPadding(0,dp(ctx,8),0,0)})
    }
    fun divisorDorado(ctx:Context):View=View(ctx).apply {
        setBackgroundColor(dorado)
        layoutParams=LinearLayout.LayoutParams(dp(ctx,74),dp(ctx,4)).apply{bottomMargin=dp(ctx,12)}
    }
}
