package xyz.vmartinez.holamundocamara02

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest
import java.security.SecureRandom

class DatosDB(ctx: Context): SQLiteOpenHelper(ctx, "fotos_unam.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE usuarios(id INTEGER PRIMARY KEY AUTOINCREMENT, nombre TEXT NOT NULL, apellidos TEXT NOT NULL, correo TEXT NOT NULL UNIQUE, sal TEXT NOT NULL, clave TEXT NOT NULL)")
        db.execSQL("CREATE TABLE fotos(id INTEGER PRIMARY KEY AUTOINCREMENT, usuario_id INTEGER NOT NULL, ruta TEXT NOT NULL, latitud REAL, longitud REAL, comentario TEXT NOT NULL, fecha TEXT NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    private fun hash(salt: String, clave: String): String = MessageDigest.getInstance("SHA-256").digest((salt+clave).toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    fun registrar(nombre: String, apellidos: String, correo: String, clave: String): Boolean {
        val bytes=ByteArray(16); SecureRandom().nextBytes(bytes)
        val salt=bytes.joinToString("") { "%02x".format(it) }
        val v=ContentValues().apply { put("nombre",nombre);put("apellidos",apellidos);put("correo",correo.trim().lowercase());put("sal",salt);put("clave",hash(salt,clave)) }
        return writableDatabase.insert("usuarios",null,v)!=-1L
    }
    fun login(correo:String,clave:String):Long {
        readableDatabase.query("usuarios",arrayOf("id","sal","clave"),"correo=?",arrayOf(correo.trim().lowercase()),null,null,null).use { c ->
            if(c.moveToFirst() && hash(c.getString(1),clave)==c.getString(2)) return c.getLong(0)
        }
        return -1
    }
    fun guardarFoto(usuario:Long, ruta:String,lat:Double?,lon:Double?,comentario:String,fecha:String):Boolean {
        val v=ContentValues().apply { put("usuario_id",usuario);put("ruta",ruta); if(lat!=null) put("latitud",lat) else putNull("latitud");if(lon!=null)put("longitud",lon) else putNull("longitud"); put("comentario",comentario);put("fecha",fecha) }
        return writableDatabase.insert("fotos",null,v)!=-1L
    }
    data class Foto(val id:Long,val ruta:String,val lat:Double?,val lon:Double?,val comentario:String,val fecha:String)
    fun fotos(usuario:Long):List<Foto> {
        val lista=mutableListOf<Foto>()
        readableDatabase.query("fotos",arrayOf("id","ruta","latitud","longitud","comentario","fecha"),"usuario_id=?",arrayOf(usuario.toString()),null,null,"id DESC").use { c ->
            while(c.moveToNext()) lista.add(Foto(c.getLong(0),c.getString(1),if(c.isNull(2))null else c.getDouble(2),if(c.isNull(3))null else c.getDouble(3),c.getString(4),c.getString(5)))
        }
        return lista
    }
}
