package xyz.vmartinez.holamundocamara02

import android.os.Bundle
import android.text.InputType
import android.util.Patterns
import androidx.appcompat.app.AppCompatActivity

class RegistroActivity:AppCompatActivity(){
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
        val l=Pantallas.columna(this);l.addView(Pantallas.encabezado(this,"Registro de usuario","Crea tu cuenta para guardar fotografías"))
        val nombre=Pantallas.campo(this,"Nombre");val apellidos=Pantallas.campo(this,"Apellidos")
        val correo=Pantallas.campo(this,"Correo electrónico",InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val clave=Pantallas.campo(this,"Contraseña (mínimo 6 caracteres)",InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        listOf(nombre,apellidos,correo,clave).forEach{l.addView(it)}
        l.addView(Pantallas.boton(this,"Guardar usuario"){
            val n=nombre.text.toString().trim();val a=apellidos.text.toString().trim();val c=correo.text.toString().trim();val p=clave.text.toString()
            if(n.isEmpty()||a.isEmpty()||!Patterns.EMAIL_ADDRESS.matcher(c).matches()||p.length<6) Pantallas.aviso(this,"Completa los datos; verifica el correo y la contraseña")
            else if(DatosDB(this).registrar(n,a,c,p)){Pantallas.aviso(this,"Usuario registrado. Inicia sesión");finish()}
            else Pantallas.aviso(this,"No se pudo registrar. Tal vez ya existe el correo")
        })
        setContentView(Pantallas.contenido(this,l))
    }
}
