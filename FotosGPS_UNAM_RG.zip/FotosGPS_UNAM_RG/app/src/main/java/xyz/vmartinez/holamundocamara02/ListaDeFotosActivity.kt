package xyz.vmartinez.holamundocamara02

import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class ListaDeFotosActivity:AppCompatActivity(){
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
        val usuario=intent.getLongExtra("usuario",-1L)
        if(usuario<0){finish();return}
        val lista=DatosDB(this).fotos(usuario)
        val l=Pantallas.columna(this)
        l.addView(Pantallas.encabezado(this,"Mis fotografías","Consulta tus imágenes y coordenadas"))
        if(lista.isEmpty()){l.addView(Pantallas.texto(this,"Todavía no hay fotos registradas"));l.addView(Pantallas.boton(this,"← Volver"){finish()});setContentView(Pantallas.contenido(this,l));return}
        val spinner=Spinner(this)
        spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,lista.map {"#${it.id} · ${it.fecha}"})
        l.addView(spinner)
        val imagen=ImageView(this).apply {adjustViewBounds=true;minimumHeight=350;scaleType=ImageView.ScaleType.FIT_CENTER}
        val detalle=Pantallas.texto(this,"")
        l.addView(imagen);l.addView(detalle)
        l.addView(Pantallas.boton(this,"← Volver"){finish()})
        setContentView(Pantallas.contenido(this,l))
        spinner.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:android.view.View?,position:Int,id:Long){
                val f=lista[position]
                if(File(f.ruta).exists()) {
                    val opt=BitmapFactory.Options().apply{inJustDecodeBounds=true}
                    BitmapFactory.decodeFile(f.ruta,opt)
                    opt.inJustDecodeBounds=false
                    opt.inSampleSize=calculateSampleSize(opt.outWidth,opt.outHeight,1000)
                    imagen.setImageBitmap(BitmapFactory.decodeFile(f.ruta,opt))
                }else imagen.setImageDrawable(null)
                detalle.text="Fecha: ${f.fecha}\nComentario: ${f.comentario.ifBlank { "Sin comentario" }}\nGPS: ${if(f.lat==null||f.lon==null) "Ubicación no disponible" else "Latitud ${f.lat}, longitud ${f.lon}"}"
            }
            override fun onNothingSelected(parent:android.widget.AdapterView<*>?){}
        }
    }
    private fun calculateSampleSize(w:Int,h:Int,max:Int):Int {var s=1;while(w/s>max*2||h/s>max*2)s*=2;return s}
}
