package xyz.vmartinez.holamundocamara02

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import androidx.appcompat.app.AppCompatActivity

class LoginActivity:AppCompatActivity(){
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
        val l=Pantallas.columna(this)
        l.addView(Pantallas.encabezado(this,"Fotos con GPS","UNAM  ·  Inicio de sesión"))
        l.addView(Pantallas.divisorDorado(this))
        val correo=Pantallas.campo(this,"Correo electrónico",InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val clave=Pantallas.campo(this,"Contraseña",InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        l.addView(correo);l.addView(clave)
        l.addView(Pantallas.boton(this,"Iniciar sesión"){
            val id=DatosDB(this).login(correo.text.toString(),clave.text.toString())
            if(id<0) Pantallas.aviso(this,"Correo o contraseña incorrectos") else startActivity(Intent(this,MainActivity::class.java).putExtra("usuario",id))
        })
        l.addView(Pantallas.boton(this,"Crear cuenta") {startActivity(Intent(this,RegistroActivity::class.java))})
        setContentView(Pantallas.contenido(this,l))
    }
}
